import React from "react";

export default function Detail() {
  return <h1>Detail</h1>;

  // TODO: Display these products details
  // return (
  //   <div id="detail">
  //     <h1>{product.name}</h1>
  //     <p>{product.description}</p>
  //     <p id="price">${product.price}</p>
  //     <img src={`/images/${product.image}`} alt={product.category} />
  //   </div>
  // );
}
